﻿using System.Text.RegularExpressions;



class Program
{

    static void Main(string[] args)
    {
        string path_read = "C:\\gore-ot-uma.txt";
        string path_write_async = "C:\\Users\\rasto\\Desktop\\result_async.txt";
        string path_write_sync = "C:\\Users\\rasto\\Desktop\\result_sync.txt";
        var dictionary = new Dictionary<string, int>();


        /*using (StreamWriter writer = new StreamWriter(path_write, true))
        {
            foreach (var item in dictionary)
            {
                await writer.WriteLineAsync(item.Key + " " + item.Value);
            }
        }*/

        ReadWriter readWriter = new ReadWriter();
        DateTime one = DateTime.Now;
        var Dict = readWriter.ReadAsync(path_read);
        DateTime two = DateTime.Now;
        var Dict2 = readWriter.Read(path_read);
        DateTime three = DateTime.Now;
        TimeSpan resultasync = two - one;
        TimeSpan resultsync = three - two;
        Console.WriteLine("Время чтения async: " + resultasync.Seconds + "sec " + resultasync.Milliseconds + "ms");
        Console.WriteLine("Время чтения line: " + resultsync.Seconds + "sec " + resultsync.Milliseconds + "ms");
        //Console.WriteLine(result.Seconds + "s " + result.Milliseconds + "ms");
        one = DateTime.Now;
        //readWriter.WriteAsync(path_write_async);
        readWriter.WriteAsync(path_write_async, dictionary);

    }
}

class ReadWriter
{    private static readonly Regex regex = new Regex(
              @"( [^\W_\d]              # starting with a letter
                            # followed by a run of either...
      ( [^\W_\d] |          #   more letters or
        [-'\d](?=[^\W_\d])  #   ', -, or digit followed by a letter
      )*
      [^\W_\d]              # and finishing with a letter
    )",
              RegexOptions.IgnorePatternWhitespace);
    
    public async Task<Dictionary<string, int>> ReadAsync(string path_read)
    {
        var dictionary = new Dictionary<string, int>();
        using (StreamReader reader = new StreamReader(path_read))
        {
            string? line;
            while ((line = await reader.ReadLineAsync()) != null)
            {
                line = line.Trim();
                foreach (Match match in regex.Matches(line))
                {
                    if (dictionary.ContainsKey(match.Groups[1].Value))
                        dictionary[match.Groups[1].Value]++;
                    else
                        dictionary.Add(match.Groups[1].Value, 1);
                }
            }
            dictionary = dictionary.OrderByDescending(pair => pair.Value).ToDictionary(pair => pair.Key, pair => pair.Value);
        }
        return dictionary;
    }
    public Dictionary<string, int> Read(string path_read)
    {
        var dictionary = new Dictionary<string, int>();
        using (StreamReader reader = new StreamReader(path_read))
        {
            string? line;
            while ((line = reader.ReadLine()) != null)
            {
                line = line.Trim();
                foreach (Match match in regex.Matches(line))
                {
                    if (dictionary.ContainsKey(match.Groups[1].Value))
                        dictionary[match.Groups[1].Value]++;
                    else
                        dictionary.Add(match.Groups[1].Value, 1);
                }
            }
            dictionary = dictionary.OrderByDescending(pair => pair.Value).ToDictionary(pair => pair.Key, pair => pair.Value);
        }
        return dictionary;
    }
    public async Task WriteAsync(string path_write, Dictionary<string, int> dictionary)
    {
        using (StreamWriter writer = new StreamWriter(path_write, true))
        {
            foreach (var item in dictionary)
            {
                await writer.WriteLineAsync(item.Key + " " + item.Value);
            }
        }
    }
    public void Write(string path_write, Dictionary<string, int> dictionary)
    {
        using (StreamWriter writer = new StreamWriter(path_write, true))
        {
            foreach (var item in dictionary)
            {
                writer.WriteLine(item.Key + " " + item.Value);
            }
        }
    }

    
}